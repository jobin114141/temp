//
//  Generated file. Do not edit.
//

// clang-format off

#import "GeneratedPluginRegistrant.h"

#if __has_include(<upi_pay/UpiPayPlugin.h>)
#import <upi_pay/UpiPayPlugin.h>
#else
@import upi_pay;
#endif

@implementation GeneratedPluginRegistrant

+ (void)registerWithRegistry:(NSObject<FlutterPluginRegistry>*)registry {
  [UpiPayPlugin registerWithRegistrar:[registry registrarForPlugin:@"UpiPayPlugin"]];
}

@end
