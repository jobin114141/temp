import 'package:flutter/material.dart';

class UiPage extends StatefulWidget {
  const UiPage({super.key});

  @override
  State<UiPage> createState() => _UiPageState();
}

class _UiPageState extends State<UiPage> {
  @override
  Widget build(BuildContext context) {
    MediaQueryData mediaQueryData = MediaQuery.of(context);
    double ScreenWidth = mediaQueryData.size.width;
    double ScreenHeight = mediaQueryData.size.height;
    return Scaffold(
        backgroundColor: Color(0xfffff9ed),
        body: Column(children: [
          Container(
              decoration: BoxDecoration(
                  color: Color(0xFFf0bf85),
                  borderRadius: BorderRadius.only(
                      bottomLeft: Radius.circular(25),
                      bottomRight: Radius.circular(25))),
              child: Column(
                mainAxisAlignment: MainAxisAlignment.start,
                children: [
                  Padding(
                    padding: const EdgeInsets.all(10.0),
                    child: Row(
                      children: [
                        Icon(Icons.menu),
                        Spacer(),
                        Icon(Icons.search)
                      ],
                    ),
                  ),
                  SizedBox(
                    height: ScreenHeight * 0.07,
                  ),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      CircleAvatar(
                        maxRadius: ScreenWidth * 0.1,
                      ),
                      SizedBox(
                        width: ScreenWidth * 0.2,
                      ),
                      Column(
                        children: [
                          Text(
                            "Sourav Suman",
                            style: TextStyle(
                                fontSize: ScreenWidth * 0.06,
                                fontWeight: FontWeight.w700),
                          ),
                          Text(
                            "App Development",
                            style: TextStyle(
                                fontSize: ScreenWidth * 0.03,
                                fontWeight: FontWeight.w400),
                          )
                        ],
                      )
                    ],
                  ),
                  SizedBox(
                    height: ScreenHeight * 0.04,
                  )
                ],
              )),
          Padding(
            padding: const EdgeInsets.all(10.0),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.start,
              children: [
                Text(
                  "My Tasks",
                  style: TextStyle(
                      fontSize: ScreenWidth * 0.04,
                      fontWeight: FontWeight.w700),
                ),
                Spacer(),
                Icon(Icons.date_range_rounded)
              ],
            ),
          ),
          Column(
            children: [
              Padding(
                padding: const EdgeInsets.all(8.0),
                child: Row(
                  children: [
                    Icon(
                      Icons.circle_notifications,
                      size: ScreenWidth * 0.1,
                    ),
                    Column(
                      mainAxisAlignment: MainAxisAlignment.start,
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          "To Do",
                          style: TextStyle(
                              fontSize: ScreenWidth * 0.03,
                              fontWeight: FontWeight.w700),
                        ),
                        Text("5 task now.1 started")
                      ],
                    )
                  ],
                ),
              ),
              Padding(
                padding: const EdgeInsets.all(8.0),
                child: Row(
                  children: [
                    Icon(
                      Icons.circle_notifications,
                      size: ScreenWidth * 0.1,
                      color: Colors.yellow,
                    ),
                    Column(
                      mainAxisAlignment: MainAxisAlignment.start,
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          "Done",
                          style: TextStyle(
                              fontSize: ScreenWidth * 0.03,
                              fontWeight: FontWeight.w700),
                        ),
                        Text("5 task now.1 started")
                      ],
                    )
                  ],
                ),
              ),
              Padding(
                padding: const EdgeInsets.all(8.0),
                child: Row(
                  children: [
                    Icon(
                      Icons.circle_notifications,
                      color: Colors.blue,
                      size: ScreenWidth * 0.1,
                    ),
                    Column(
                      mainAxisAlignment: MainAxisAlignment.start,
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          "In Progress",
                          style: TextStyle(
                              fontSize: ScreenWidth * 0.03,
                              fontWeight: FontWeight.w700),
                        ),
                        Text("5 task now.1 started")
                      ],
                    )
                  ],
                ),
              ),
              Padding(
                padding: const EdgeInsets.all(10.0),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.start,
                  children: [
                    Text(
                      "Active Projects",
                      style: TextStyle(
                          fontSize: ScreenWidth * 0.04,
                          fontWeight: FontWeight.w800),
                    ),
                  ],
                ),
              ),
              Card(
                child: Container(
                  width: ScreenWidth * 0.25,height: ScreenHeight * 0.2,
                  child: Column(mainAxisAlignment: MainAxisAlignment.center,
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Center(
                        child: Container(
                          child: Text("25%"),
                        ),
                      ),
                      Padding(
                        padding:  EdgeInsets.only(left: 10, bottom: 2),
                        child: Text("Medical App"),
                      ),
                      Padding(
                        padding: const EdgeInsets.only(left: 10),
                        child: Text("6 hours program"),
                      )
                    ],
                  ),
                ),
              )
            ],
          )
        ]));
  }
}
